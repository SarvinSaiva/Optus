package config;

import static executionEngine.TC001_Reports_Contract_Management.OR;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import utility.ExcelUtils;
import utility.Log;
import atu.testng.reports.ATUReports;
import atu.testng.reports.listeners.ATUReportsListener;
import atu.testng.reports.listeners.ConfigurationListener;
import atu.testng.reports.listeners.MethodListener;
import atu.testng.reports.logging.LogAs;
import atu.testng.selenium.reports.CaptureScreen;
import atu.testng.selenium.reports.CaptureScreen.ScreenshotOf;

import com.google.common.io.Files;

import executionEngine.TC001_Reports_Contract_Management;
import executionEngine.TC002_Reports_Cost_Management;
import executionEngine.TC003_Reports_Design_Management;
import executionEngine.TC004_Reports_Logistic;
import executionEngine.TC005_Reports_Project_Management;
import executionEngine.TC006_Reports_Schedule_Management;

@Listeners({ ATUReportsListener.class, ConfigurationListener.class,
	MethodListener.class })
@SuppressWarnings("unused")
public class ActionKeywords {

    {
	System.setProperty("atu.reporter.config", "D:\\ZOptus_Projects\\DMS_Hybrid_Regression_IBM\\ATU\\atu.properties");
    }

    public static WebDriver driver;
    public static String sReportRunMode;

    @Test
    public static void openBrowser(String object, String data) {
	Log.info("Opening Browser");
	try {
	    if (data.equals("Mozilla")) {
		driver = new FirefoxDriver();
		Log.info("Mozilla browser started");
	    } else if (data.equals("IE")) {
		// Dummy Code, Implement you own code
		driver = new InternetExplorerDriver();
		Log.info("IE browser started");
	    } else if (data.equals("Chrome")) {
		// Dummy Code, Implement you own code
		/*
		 * System.setProperty("webdriver.chrome.driver",
		 * "D:\\ChromeDriver\\chromedriver.exe");
		 */

		/*ChromeOptions options = new ChromeOptions();
		options.addArguments("chrome.switches", "--disable-extensions");
		System.setProperty("webdriver.chrome.driver",
			"D:\\Auto\\chromedriver_win32\\chromedriver.exe");*/

	    	System.setProperty("webdriver.chrome.driver",
					"D:\\Auto\\chromedriver_win32\\chromedriver.exe");
			DesiredCapabilities capabilities = DesiredCapabilities.chrome();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("test-type");
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
			chromePrefs.put("download.default_directory",
					"D:\\AutomationTesting_DMS\\DownloadedFile\\");
			options.setExperimentalOption("prefs", chromePrefs);
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			driver = new ChromeDriver(capabilities);
		ATUReports.setWebDriver(driver);
		ATUReports.indexPageDescription = "DMS Project";

		//driver = new ChromeDriver(options);
		
		

		// driver = new ChromeDriver();
		Log.info("Chrome browser started");
		// Reporter.log("Chrome browser started"+data);
	    }

	    int implicitWaitTime = (10);
	    driver.manage().timeouts()
		    .implicitlyWait(implicitWaitTime, TimeUnit.SECONDS);
	} catch (Exception e) {
	    Log.info("Not able to open the Browser --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void navigate(String object, String data) {
	try {
	    Log.info("Navigating to URL");
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    driver.get(Constants.URL);
	} catch (Exception e) {
	    Log.info("Not able to navigate --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }
    

    @Test
    public static void click(String object, String data) {
	try {
	    Log.info("Clicking on Webelement " + object);
	    driver.findElement(By.xpath(OR.getProperty(object))).click();
	} catch (Exception e) {
	    Log.error("Not able to click --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void input(String object, String data) {
	try {
	    Log.info("Entering the text in " + object);
	    // driver.findElement(By.xpath(OR.getProperty(object))).clear();
	    driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(data);
	} catch (Exception e) {
	    Log.error("Not able to Entering the text --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void waitFor(String object, String data) throws Exception {
	try {
	    Log.info("Wait for 5 seconds");
	    Wait<WebDriver> wait = new WebDriverWait(driver, 30);
	    try {
		wait.wait();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.MINUTES);
		// Thread.sleep(5000);
	    } catch (Throwable error) {
		assertFalse(
			"Timeout waiting for Page Load Request to complete.",
			true);
	    }
	} catch (Exception e) {
	    Log.error("Not able to Wait --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void waitFor_60sec(String object, String data)
	    throws Exception {
	try {
	    Log.info("Wait for 60 seconds");
	    try {
		Thread.sleep(60000);
		// ReportVal(object, data);
		// driver.manage().timeouts().implicitlyWait(60,
		// TimeUnit.SECONDS);
	    } catch (Throwable error) {
		assertFalse(
			"Timeout waiting for Page Load Request to complete.",
			true);
	    }
	} catch (Exception e) {
	    Log.error("Not able to Wait --- " + e.getMessage());
	}
    }

    @Test
    public static void waitFor_30sec(String object, String data)
	    throws Exception {
	try {
	    Log.info("Wait for 30 seconds");
	    try {
		Thread.sleep(30000);
		// ReportVal(object, data);
		// driver.manage().timeouts().implicitlyWait(60,
		// TimeUnit.SECONDS);
	    } catch (Throwable error) {
		assertFalse(
			"Timeout waiting for Page Load Request to complete.",
			true);
	    }
	} catch (Exception e) {
	    Log.error("Not able to Wait --- " + e.getMessage());
	}
    }

    @Test
    public static void waitFor_15sec(String object, String data)
	    throws Exception {
	try {
	    Log.info("Wait for 15 seconds");
	    try {
		Thread.sleep(15000);
		// ReportVal(object, data);
		// driver.manage().timeouts().implicitlyWait(60,
		// TimeUnit.SECONDS);
	    } catch (Throwable error) {
		assertFalse(
			"Timeout waiting for Page Load Request to complete.",
			true);
	    }
	} catch (Exception e) {
	    Log.error("Not able to Wait --- " + e.getMessage());
	}
    }

    @Test
    public static void waitFor_10sec(String object, String data)
	    throws Exception {
	try {
	    Log.info("Wait for 10 seconds");
	    try {
		Thread.sleep(10000);
		// ReportVal(object, data);
		// driver.manage().timeouts().implicitlyWait(60,
		// TimeUnit.SECONDS);
	    } catch (Throwable error) {
		assertFalse(
			"Timeout waiting for Page Load Request to complete.",
			true);
	    }
	} catch (Exception e) {
	    Log.error("Not able to Wait --- " + e.getMessage());
	}
    }

    @Test
    public static void waitFor_5sec(String object, String data)
	    throws Exception {
	try {
	    Log.info("Wait for 5 seconds");
	    try {
		Thread.sleep(5000);
		// ReportVal(object, data);
		// driver.manage().timeouts().implicitlyWait(60,
		// TimeUnit.SECONDS);
	    } catch (Throwable error) {
		assertFalse(
			"Timeout waiting for Page Load Request to complete.",
			true);
	    }
	} catch (Exception e) {
	    Log.error("Not able to Wait --- " + e.getMessage());
	}
    }

    @Test
    public static void waitFor_1sec(String object, String data)
	    throws Exception {
	try {
	    Log.info("Wait for 1 seconds");
	    try {
		Thread.sleep(1000);
		// ReportVal(object, data);
		// driver.manage().timeouts().implicitlyWait(60,
		// TimeUnit.SECONDS);
	    } catch (Throwable error) {
		assertFalse(
			"Timeout waiting for Page Load Request to complete.",
			true);
	    }
	} catch (Exception e) {
	    Log.error("Not able to Wait --- " + e.getMessage());
	}
    }

    @Test
    public static void waitFormin(String object, String data) throws Exception {
	try {
	    Log.info("Wait for 3 seconds");
	    Wait<WebDriver> wait = new WebDriverWait(driver, 30);
	    try {
		wait.wait();
	    } catch (Throwable error) {
		assertFalse(
			"Timeout waiting for Page Load Request to complete.",
			true);
	    }
	} catch (Exception e) {
	    Log.error("Not able to Wait --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    private static void assertFalse(String string, boolean b) {

    }

    @Test
    public static void closeBrowser(String object, String data) {
	try {
	    Log.info("Closing the browser");
	    driver.quit();
	} catch (Exception e) {
	    Log.error("Not able to Close the Browser --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void SelectText(String object, String data) {
	try {
	    Log.info("Select the text" + object);
	    Select oSelection = new Select(driver.findElement(By.xpath(OR
		    .getProperty(object))));
	    oSelection.selectByVisibleText(data);

	} catch (Exception e) {
	    Log.error("Not able to Select the text --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void MouseOver(String object, String data) {
	try {
	    Log.info("Mouse over on menu" + object);
	    WebElement element = driver.findElement(By.xpath(OR
		    .getProperty(object)));
	    Actions action = new Actions(driver);
	    action.moveToElement(element).build().perform();
	} catch (Exception e) {
	    Log.error("Not able to Mouse Over on Menu --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void MouseOverClick(String object, String data) {
	try {
	    Log.info("Mouse Over click on Menu" + object);
	    WebElement element = driver.findElement(By.xpath(OR
		    .getProperty(object)));
	    Actions action = new Actions(driver);
	    action.moveToElement(element).click().build().perform();
	} catch (Exception e) {
	    Log.error("Not able to Mouse over click on Menu --- "
		    + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void Takescreenshots(String object, String data) {

	String path = null;
	try {
	    File source = ((TakesScreenshot) driver)
		    .getScreenshotAs(OutputType.FILE);
	    Calendar currentDate = Calendar.getInstance();
	    SimpleDateFormat formatter = new SimpleDateFormat(
		    "yyyy/MMM/dd HH:mm:ss");
	    String dateN = formatter.format(currentDate.getTime()).replace("/",
		    "_");
	    String dateNow = dateN.replace(":", "_");
	    String snapShotDirectory = Files.getNameWithoutExtension(dateNow);

	    File f = new File(snapShotDirectory);
	    if (f.mkdir()) {
		path = f.getAbsolutePath() + "/" + source.getName();
		FileUtils.copyFile(source, new File(path));
	    }
	} catch (IOException e) {
	    path = "Failed to capture screenshot: " + e.getMessage();
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}

    }

    @Test
    public static void NewWindowHandle(String object, String data) {
	try {
	    String newwin = driver.getWindowHandle();
	    Log.info("Switch to New window --- " + newwin);
	    Set<String> Handles = driver.getWindowHandles();
	    Iterator<String> it = Handles.iterator();
	    while (it.hasNext()) {
		newwin = it.next();
	    }

	    driver.switchTo().window(newwin);
	    if (data.equals("issueDetails")) {
		driver.switchTo().frame("ifrm1");
	    }

	} catch (Exception e) {
	    Log.error("Not able to Switch to New window --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}

    }

    @Test
    public static void ParentWindowHandle(String object, String data) {
	try {
	    // String object1 = driver.getWindowHandle();

	    Set<String> allWindowHandles = driver.getWindowHandles();
	    Log.info("Switch to Parent window --- " + allWindowHandles);

	    for (String currentWindowHandle : allWindowHandles) {
		if (!currentWindowHandle.equals(allWindowHandles)) {
		    driver.switchTo().window(currentWindowHandle);
		}
	    }
	} catch (Exception e) {
	    Log.error("Not able to Switch to Parent window --- "
		    + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}

    }

    @Test
    public static void RadioButton(String object, String data) {
	try {
	    Log.info("Clicking on Radio button --- " + object);
	    driver.findElement(By.xpath(OR.getProperty(object))).click();
	} catch (Exception e) {
	    Log.error("Not able to click on Radio button --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}

    }

    @Test
    public static void Navigateurl(String object, String data) {
	try {
	    Log.info("Navigating to URL");
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    driver.get(Constants.NavigateURL);
	} catch (Exception e) {
	    Log.info("Not able to navigate --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void FileUpload(String object, String data) {
	try {
	    Log.info("File Upload Attachment uploaded ---" + object);
	    WebElement filepath = driver.findElement(By.xpath(OR
		    .getProperty(object)));
	    filepath.sendKeys(data);
	} catch (Exception e) {
	    Log.info("Not able to upload attached file --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void AlertAccpet(String object, String data) {
	try {
	    Log.info("Click on Accept Alert Message --- " + data);
	    // Accept alert box
	    driver.switchTo().alert().accept();
	} catch (Exception e) {
	    Log.info("Not able to Click on Alert Message --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void AlertDismiss(String object, String data) {
	try {
	    Log.info("Click on Dismiss Alert Message --- " + data);
	    // Accept alert box
	    driver.switchTo().alert().dismiss();
	} catch (Exception e) {
	    Log.info("Not able to Click on Dismiss Alert Message --- "
		    + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void NavigateNextpage(String object, String data) {
	try {
	    Log.info("Navigate to Next page --- " + data);
	    driver.navigate().forward();
	} catch (Exception e) {
	    Log.info("Not able to Navigate Next Page --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void NavigateBackpage(String object, String data) {
	try {
	    Log.info("Navigate to Back page --- " + object);
	    driver.navigate().back();
	} catch (Exception e) {
	    Log.info("Not able to Navigate back Page --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void Refresh(String object, String data) {
	try {
	    Log.info("Refresh the current page --- " + object);
	    driver.navigate().refresh();
	} catch (Exception e) {
	    Log.info("Not able to Refresh the current page --- "
		    + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void Maximize(String object, String data) {
	try {
	    Log.info("Maximize the current page --- " + object);
	    driver.manage().window().maximize();
	} catch (Exception e) {
	    Log.info("Not able to maximize the current page --- "
		    + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void close(String object, String data) {
	try {
	    Log.info("Close the current page --- " + object);
	    driver.close();

	} catch (Exception e) {
	    Log.info("Not able to close the current page --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}

    }

    @Test
    public static void KeysTab(String object, String data) {
	try {

	    Log.info("Keys tab on Text box --- " + object);
	    driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(
		    Keys.TAB);
	} catch (Exception e) {
	    Log.info("Not able to keys Tab on Text box --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void KeysDown(String object, String data) {
	try {

	    Log.info("Keys Down on Text box --- " + object);

	    Actions actions = new Actions(driver);
	    actions.keyDown(Keys.ARROW_DOWN);
	    actions.perform();

	} catch (Exception e) {
	    Log.info("Not able to keys Down on Text box --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void KeysEnter(String object, String data) {
	try {

	    Log.info("Keys Enter on Text box --- " + object);
	    driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(
		    Keys.ENTER);
	} catch (Exception e) {
	    Log.info("Not able to keys Enter on Text box --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void KeysShift(String object, String data) {
	try {

	    Log.info("Press Shift Key on Text box --- " + object);
	    driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(
		    Keys.SHIFT);
	} catch (Exception e) {
	    Log.info("Not able to Press shift key on Text box --- "
		    + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void Doubleclick(String object, String data) {
	try {

	    Log.info("Double click on Text box --- " + object);
	    Actions action = new Actions(driver);
	    action.moveToElement(
		    driver.findElement(By.xpath(OR.getProperty(object))))
		    .doubleClick().build().perform();
	} catch (Exception e) {
	    Log.info("Not able to double click on Text box --- "
		    + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void KeysEnd(String object, String data) {
	try {

	    Log.info("Press End Key click on Text box --- " + object);
	    driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(
		    Keys.END);
	} catch (Exception e) {
	    Log.info("Not able to Press End Key click on Text box --- "
		    + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void KeysHome(String object, String data) {
	try {

	    Log.info("Press Home Key click on Text box --- " + object);
	    driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(
		    Keys.HOME);
	} catch (Exception e) {
	    Log.info("Not able to Press Home Key click on Text box --- "
		    + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}

    }

    @Test
    public static void KeysEscape(String object, String data) {
	try {

	    Log.info("Press Escape Key click on Text box --- " + object);
	    Robot robot = new Robot();
	    robot.keyPress(KeyEvent.VK_ESCAPE);
	} catch (Exception e) {
	    Log.info("Not able to Press Escape Key click on Text box --- "
		    + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void KeysDownArrowMul(String object, String data) {
	try {
	    Log.info("Press Keys down arrow on Text value" + object);

	    List<WebElement> menuitems = driver.findElements(By
		    .className("ui-menu-item"));
	    int menulgth = menuitems.size();

	    // System.out.println(menuitems.size());
	    if (menulgth >= 1) {
		for (int i = 0; i <= menulgth - 1; i++) {
		    Robot robot = new Robot();
		    robot.keyPress(KeyEvent.VK_DOWN);
		}
	    } else {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
	    }

	    // robot.keyPress(KeyEvent.VK_DOWN);
	    // robot.keyPress(KeyEvent.VK_F4);

	    /*
	     * Actions actions = new Actions(driver);
	     * actions.keyDown(Keys.ARROW_DOWN); actions.perform();
	     */
	} catch (Exception e) {
	    Log.info("Not able to Press Keys down arrow on on Text value --- "
		    + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void KeysDownArrowSing(String object, String data) {
	try {
	    Log.info("Press Keys down arrow on Text value" + object);
	    Robot robot = new Robot();
	    robot.keyPress(KeyEvent.VK_DOWN);

	} catch (Exception e) {
	    Log.info("Not able to Press Keys down arrow on on Text value --- "
		    + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void KeysEnterAction(String object, String data) {
	try {
	    Log.info("Press Keys Enter on Text value" + object);
	    Robot robot = new Robot();
	    robot.keyPress(KeyEvent.VK_ENTER);

	} catch (Exception e) {
	    Log.info("Not able to Press Keys Enter on on Text value --- "
		    + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void KeysPagedown(String object, String data) {
	try {
	    Log.info("Press Key PageDown on Text value --- " + object);
	    Robot robot = new Robot();
	    robot.keyPress(KeyEvent.VK_PAGE_DOWN);

	} catch (Exception e) {
	    Log.info("Not able to Press Key PageDown on Text value --- "
		    + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void KeysPageUp(String object, String data) {
	try {
	    Log.info("Press Key PageUp on Text value --- " + object);
	    Robot robot = new Robot();
	    robot.keyPress(KeyEvent.VK_PAGE_UP);

	} catch (Exception e) {
	    Log.info("Not able to Press Key PageUp on Text value --- "
		    + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void ClsAllExcptMain(String object, String data) {
	try {
	    Log.info("Close Other Window Handles --- " + object);
	    String mainWindow = getMainWindowHandle();
	    closeAllOtherWindows(mainWindow);
	} catch (Exception e) {

	    Log.info("Not able to Close Other Window Handles --- "
		    + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}

    }

    @Test
    public static String getMainWindowHandle() {
	return driver.getWindowHandle();
    }

    @Test
    // To close all the other windows except the main window.
    public static void closeAllOtherWindows(String openWindowHandle) {
	try {

	    Log.info("Close Other Window Handles --- " + openWindowHandle);
	    Set<String> allWindowHandles = driver.getWindowHandles();

	    for (String currentWindowHandle : allWindowHandles) {
		if (!currentWindowHandle.equals(openWindowHandle)) {
		    driver.switchTo().window(openWindowHandle);
		    driver.close();
		    driver.switchTo().window(currentWindowHandle);

		}
	    }

	} catch (Exception e) {

	    Log.info("Not able to Close Other Window Handles --- "
		    + e.getMessage());

	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}

    }

    @Test
    public void AltplusF4(String object, String data) {
	try {
	    Log.info("Press Keys ALT + F4 on Current Page" + object);
	    Robot robot = new Robot();
	    robot.keyPress(KeyEvent.VK_ALT);
	    robot.keyPress(KeyEvent.VK_F4);

	} catch (Exception e) {
	    Log.info("Not able to Press Keys Ctrl + F4 on Current Page --- "
		    + e.getMessage());

	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void Validation(String object, String data) {
	try {
	    Log.info("Validate current Text --- " + object);
	    WebElement Txt = driver
		    .findElement(By.xpath(OR.getProperty(object)));
	    String CheckText = Txt.getText();

	    WebElement Rprcnt = driver.findElement(By
		    .xpath("//*[@id='ReportViewer1_fixedTable']/tbody/tr[4]"));

	    if (CheckText.equals(data) && Rprcnt.isDisplayed()) {
		Log.info("Text Matched with given value --- " + CheckText);
		System.out.println("Text Matched with given value... ");

		ATUReports.add("Text Matched with given value", data,
			CheckText, LogAs.PASSED, new CaptureScreen(
				ScreenshotOf.DESKTOP));

	    } else if (!CheckText.equals(data) && Rprcnt.isDisplayed()) {
		Log.info("Text not Matched with given value --- " + CheckText);
		System.out.println("Text not Matched with given value... ");

		ATUReports.add("Text not Matched with given value", data,
			CheckText, LogAs.FAILED, new CaptureScreen(
				ScreenshotOf.DESKTOP));

	    }
	} catch (Exception e) {
	    Log.info("Not able to Validate current Text --- " + e.getMessage());

	}
    }

    @Test
    public void TxtbxValidation(String object, String data) {
	try {
	    Log.info("Validate current Text --- " + object);
	    WebElement Txt = driver
		    .findElement(By.xpath(OR.getProperty(object)));
	    String Textbx = Txt.getAttribute("value");
	    if (Textbx.contains(data)) {
		Log.info("Text Matched with given value --- " + Textbx);
		System.out.println("Textbox Validation check working fine...");
	    } else {
		Log.info("Text not Matched with given value --- " + Textbx);
		System.out
			.println("Textbox Validation check not working fine...");
	    }
	} catch (Exception e) {
	    Log.info("Not able to Validate current Text --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public void switchtoframe(String object, String data) {
	try {
	    Log.info("Switch to New frame --- " + object);
	    driver.switchTo().frame(object);
	} catch (Exception e) {
	    Log.info("Not able to Switch to New frame --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public void switchtowindow(String object, String data) {
	try {
	    Log.info("Switch to New window --- " + object);
	    driver.switchTo().window(object);
	} catch (Exception e) {
	    Log.info("Not able to Switch to New window --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public void CheckboxChecked(String object, String data) {
	try {
	    Log.info("Checked the check box --- " + object);
	    WebElement oCheckBox = driver.findElement(By.xpath(OR
		    .getProperty(object)));
	    if (!oCheckBox.isSelected()) {
		oCheckBox.click();
	    }

	} catch (Exception e) {
	    Log.info("Not able to Checked the check box --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public void RadiobuttonClick(String object, String data) {
	try {
	    Log.info("Checked the Radio button --- " + object);
	    WebElement radioBtn = driver.findElement(By.xpath(OR
		    .getProperty(object)));
	    radioBtn.click();
	} catch (Exception e) {
	    Log.info("Not able to Checked the Radio button --- "
		    + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void KeysSpaceAction(String object, String data) {
	try {
	    Log.info("Press Keys Enter on Text value" + object);
	    Robot robot = new Robot();
	    robot.keyPress(KeyEvent.VK_SPACE);

	} catch (Exception e) {
	    Log.info("Not able to Press Keys Enter on on Text value --- "
		    + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    @Test
    public static void Datepicker(String object, String data) {

	DateFormat dateFormat2 = new SimpleDateFormat("dd");
	Date date2 = new Date();

	String today = dateFormat2.format(date2);

	// find the calendar
	WebElement dateWidget = driver.findElement(By.xpath(OR
		.getProperty(object)));
	List<WebElement> columns = dateWidget.findElements(By.tagName("td"));

	// comparing the text of cell with today's date and clicking it.
	for (WebElement cell : columns) {
	    if (!cell.getText().equals(today)) {
		cell.click();
		break;
	    }
	}
    }

    @Test
    public static void setClipboardData(String object) {
	StringSelection stringSelection = new StringSelection(object);
	Toolkit.getDefaultToolkit().getSystemClipboard()
		.setContents(stringSelection, null);

    }

    @Test
    public void CtrlVNaviteKeyStroke(String object, String data) {

	setClipboardData(data);
	// native key strokes for CTRL, V and ENTER keys

	try {
	    Robot robot = new Robot();

	    robot.keyPress(KeyEvent.VK_CONTROL);
	    robot.keyPress(KeyEvent.VK_V);
	    robot.keyRelease(KeyEvent.VK_V);
	    robot.keyRelease(KeyEvent.VK_CONTROL);
	    robot.keyPress(KeyEvent.VK_ENTER);
	    robot.keyRelease(KeyEvent.VK_ENTER);

	} catch (AWTException e) {
	    e.printStackTrace();
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	}
    }

    @Test
    public void WebTableClick(String object, String data) {

	switch (data) {
	case "workSearchResults":
	    /*
	     * List<WebElement> sRowValue = driver .findElements(By .xpath(
	     * ".//*[@id='workSearchResults']/div[1]/div[1]/div/div[1]/table/tbody/tr"
	     * )); int Rows = sRowValue.size(); // System.out.println(Rows);
	     * 
	     * List<WebElement> sColumnValue = driver .findElements(By .xpath(
	     * ".//*[@id='workSearchResults']/div[1]/div[2]/div/div/div[1]/table/thead/tr/th"
	     * )); int Colums = sColumnValue.size(); //
	     * System.out.println(Colums);
	     * 
	     * for (int i = 1; i <= Rows; i++) {
	     * 
	     * for (int j = 1; j <= Colums; j++) {
	     */
	    driver.findElement(
		    By.xpath(".//*[@id='workSearchResults']/div[1]/div[1]/div/div[1]/table/tbody/tr[1]/td[1]"))
		    .click();
	    // }
	    // }
	    break;

	case "handsoncontainer":

	    try {
		List<WebElement> sRowValue1 = driver
			.findElements(By
				.xpath(".//*[@id='handsoncontainer']/div[1]/div[1]/div/div[1]/table/tbody/tr"));
		int sRows = sRowValue1.size();
		// System.out.println("Rows count"+sRows);

		List<WebElement> sColumnValue1 = driver
			.findElements(By
				.xpath(".//*[@id='handsoncontainer']/div[1]/div[2]/div/div/div[1]/table/thead/tr/th"));
		int sColums = sColumnValue1.size();
		// System.out.println("Colums count"+sColums);

		for (int i = 0; i <= sRows; i++) {
		    for (int j = 1; j <= sColums; j++) {
			if (i == (sRows - 1)) {
			    WebElement sClickrow = driver
				    .findElement(By
					    .xpath(".//*[@id='handsoncontainer']/div[1]/div[1]/div/div[1]/table/tbody/tr["
						    + sRows + "]/td[1]/button"));
			    // System.out.println("Total minus 1 rows value"+(sRows-1));
			    sClickrow.click();
			    break;
			}

		    }
		}

	    } catch (Exception e) {

		Log.info("Not able to Click on Edit button in Webtable --- "
			+ e.getMessage());

	    }
	    break;

	case "handsoncontainerMilestone":
	    List<WebElement> sRowValue2 = driver
		    .findElements(By
			    .xpath(".//*[@id='handsoncontainer']/div[1]/div[1]/div/div[1]/table/tbody/tr"));
	    int Rows2 = sRowValue2.size();
	    // System.out.println(Rows2);

	    List<WebElement> sColumnValue2 = driver
		    .findElements(By
			    .xpath(".//*[@id='handsoncontainer']/div[1]/div[2]/div/div/div[1]/table/thead/tr/th"));
	    int Colums2 = sColumnValue2.size();
	    // System.out.println(Colums2);

	    for (int i = 1; i <= Rows2; i++) {

		for (int j = 1; j <= Colums2; j++) {

		    driver.findElement(
			    By.xpath(".//*[@id='handsoncontainer']/div[1]/div[1]/div/div[1]/table/tbody/tr["
				    + (Rows2 - 1)
				    + "]/td["
				    + (Colums2 - 9)
				    + "]")).click();
		}
	    }
	    break;

	case "NewInvoices":
	    List<WebElement> sRowValue3 = driver.findElements(By
		    .xpath(".//*[@id='data-table']/tbody/tr"));
	    int Rows3 = sRowValue3.size();
	    // System.out.println(Rows3);

	    List<WebElement> sColumnValue3 = driver.findElements(By
		    .xpath(".//*[@id='data-table']/thead/tr/th"));
	    int Colums3 = sColumnValue3.size();
	    // System.out.println(Colums3);

	    for (int i = 0; i <= Rows3 - 1; i++) {

		for (int j = 1; j <= Colums3; j++) {
		    WebElement oCheckBox = driver
			    .findElement(By
				    .xpath(".//*[@id='data-table']/tbody/tr[1]/td[2]/input"));
		    // driver.findElement(By.xpath(".//*[@id='data-table']/tbody/tr[2]/td[2]/input")).click();
		    if (!oCheckBox.isSelected()) {
			oCheckBox.click();
		    }
		}
	    }
	    break;

	case "InvoiceApproved":

	    List<WebElement> sRowValue4 = driver.findElements(By
		    .xpath(".//*[@id='data-table1']/tbody/tr"));
	    int Rows4 = sRowValue4.size();
	    // System.out.println(Rows4);

	    List<WebElement> sColumnValue4 = driver.findElements(By
		    .xpath(".//*[@id='data-table1']/thead/tr/th"));
	    int Colums4 = sColumnValue4.size();
	    // System.out.println(Colums4);

	    for (int i = 0; i < Rows4 - 1; i++) {

		for (int j = 1; j <= Colums4; j++) {

		    WebElement oCheckBox = driver
			    .findElement(By
				    .xpath(".//*[@id='data-table1']/tbody/tr/td[2]/input"));

		    if (!oCheckBox.isSelected()) {
			oCheckBox.click();
		    }
		    // driver.findElement(By.xpath(".//*[@id='data-table']/tbody/tr[2]/td[2]/input")).click();
		}
	    }
	    break;

	}
    }

    @Test
    public void selectDate(String object, String data) {
	// data.toString();
	// driver.findElement(By.xpath(object)).clear();
	// driver.findElement(By.xpath(OR.getProperty(object))).sendKeys("");

	/*
	 * String Year = driver.findElement(
	 * By.cssSelector("span.ui-datepicker-year")).getText();
	 * //System.out.println(Year); String SelectedDate = driver.findElement(
	 * By.cssSelector(".ui-state-highlight")).getText();
	 */
	// for(int i=1;i<=31;i++){
	switch (data) {
	case "1":
	    driver.findElement(
		    By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[1]/td[4]/a"))
		    .click();
	    break;
	case "2":
	    driver.findElement(By.xpath("//div/table/tbody/tr[1]/td[2]/a"))
		    .click();
	    break;
	case "3":
	    driver.findElement(By.xpath("//div/table/tbody/tr[1]/td[3]/a"))
		    .click();
	    break;
	case "4":
	    driver.findElement(By.xpath("//div/table/tbody/tr[1]/td[4]/a"))
		    .click();
	    break;
	case "5":
	    driver.findElement(
		    By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[2]/td[1]/a"))
		    .click();
	    break;
	case "6":
	    driver.findElement(
		    By.xpath("/html/body/div[7]/div[1]/table/tbody/tr[2]/td[6]"))
		    .click();
	    break;
	case "7":
	    driver.findElement(By.xpath("//div/table/tbody/tr[1]/td[7]/a"))
		    .click();
	    break;
	case "8":
	    driver.findElement(By.xpath("//div/table/tbody/tr[2]/td[1]/a"))
		    .click();
	    break;
	case "9":
	    driver.findElement(By.xpath("//div/table/tbody/tr[2]/td[2]/a"))
		    .click();
	    break;
	case "10":
	    driver.findElement(By.xpath("//div/table/tbody/tr[2]/td[6]/a"))
		    .click();
	    break;
	case "11":
	    driver.findElement(By.xpath("//div/table/tbody/tr[2]/td[4]/a"))
		    .click();
	    break;
	case "12":
	    driver.findElement(By.xpath("//div/table/tbody/tr[2]/td[5]/a"))
		    .click();
	    break;
	case "13":
	    driver.findElement(By.xpath("//div/table/tbody/tr[2]/td[6]/a"))
		    .click();
	    break;
	case "14":
	    driver.findElement(By.xpath("//div/table/tbody/tr[2]/td[7]/a"))
		    .click();
	    break;
	case "15":
	    driver.findElement(By.xpath("//div/table/tbody/tr[3]/td[4]/a"))
		    .click();
	    break;
	case "16":
	    driver.findElement(By.xpath("//div/table/tbody/tr[3]/td[2]/a"))
		    .click();
	    break;
	case "17":
	    driver.findElement(By.xpath("//div/table/tbody/tr[3]/td[3]/a"))
		    .click();
	    break;
	case "18":
	    driver.findElement(By.xpath("//div/table/tbody/tr[3]/td[4]/a"))
		    .click();
	    break;
	case "19":
	    driver.findElement(By.xpath("//div/table/tbody/tr[3]/td[5]/a"))
		    .click();
	    break;
	case "20":
	    driver.findElement(By.xpath("//div/table/tbody/tr[3]/td[6]/a"))
		    .click();
	    break;
	case "21":
	    driver.findElement(By.xpath("//div/table/tbody/tr[3]/td[7]/a"))
		    .click();
	    break;
	case "22":
	    driver.findElement(By.xpath("//div/table/tbody/tr[4]/td[1]/a"))
		    .click();
	    break;
	case "23":
	    driver.findElement(By.xpath("//div/table/tbody/tr[4]/td[2]/a"))
		    .click();
	    break;
	case "24":
	    driver.findElement(By.xpath("//div/table/tbody/tr[4]/td[3]/a"))
		    .click();
	    break;
	case "25":
	    driver.findElement(By.xpath("//div/table/tbody/tr[4]/td[4]/a"))
		    .click();
	    break;
	case "26":
	    driver.findElement(By.xpath("//div/table/tbody/tr[4]/td[5]/a"))
		    .click();
	    break;
	case "27":
	    driver.findElement(By.xpath("//div/table/tbody/tr[4]/td[6]/a"))
		    .click();
	    break;
	case "28":
	    driver.findElement(By.xpath("//div/table/tbody/tr[4]/td[7]/a"))
		    .click();
	    break;
	case "29":
	    driver.findElement(By.xpath("//div/table/tbody/tr[5]/td[1]/a"))
		    .click();
	    break;
	case "30":
	    driver.findElement(By.xpath("//div/table/tbody/tr[5]/td[2]/a"))
		    .click();
	    break;
	case "31":
	    driver.findElement(By.xpath("//div/table/tbody/tr[5]/td[3]/a"))
		    .click();
	    break;
	// }
	// break;
	}

    }

    @SuppressWarnings({ "unchecked", "static-access" })
    @Test
    public static void Untilwait(String object, String data) {
	try {

	    Log.info("Untill wait for Element visible --- " + object);
	    // WebDriverWait wait = new WebDriverWait(driver, 60);
	    /*
	     * WebDriverWait wait = new WebDriverWait(driver, 100);
	     * wait.until(ExpectedConditions.visibilityOfElementLocated(By
	     * .id("ReportViewer1_fixedTable")));
	     */

	    // wait.wait();

	    int timeout = 240;
	    WebElement by = null;
	    WebElement By = by;
	    WebDriverWait innerwait = new WebDriverWait(driver, timeout);
	    if (driver.findElement((org.openqa.selenium.By) by).isDisplayed()) {
		innerwait.until(ExpectedConditions
			.presenceOfElementLocated(((org.openqa.selenium.By) By)
				.xpath(OR.getProperty(object))));

		innerwait
			.until(ExpectedConditions
				.visibilityOfAllElements((List<WebElement>) ((org.openqa.selenium.By) By)
					.xpath(OR.getProperty(object))));

	    } else {

		ATUReports.add("Report Timeout error ", LogAs.FAILED,
			new CaptureScreen(ScreenshotOf.DESKTOP));

		ClsAllExcptMain(object, data);
	    }

	    /*
	     * int timeout = 120; WebDriverWait innerwait = new
	     * WebDriverWait(driver, timeout); if
	     * (innerwait.withTimeout(timeout, TimeUnit.MINUTES) != null) {
	     * innerwait.until(ExpectedConditions
	     * .visibilityOfElementLocated(By.xpath(OR .getProperty(object))));
	     * } else {
	     * 
	     * ATUReports.add("Report Timeout error ", LogAs.FAILED, new
	     * CaptureScreen(ScreenshotOf.DESKTOP)); ClsAllExcptMain(object,
	     * data); }
	     */
	} catch (Exception e) {
	    Log.info("Not able to wait for Element visible --- "
		    + e.getMessage());
	}
    }

    @Test
    public static void UntilDlwait(String object, String data) {
	try {

	    Log.info("Untill wait for Element visible --- " + object);
	    // Thread.sleep(10000);
	    int timeOut = 0;
	    WebDriverWait wait = new WebDriverWait(driver, timeOut);
	    Boolean element = wait.until(ExpectedConditions
		    .invisibilityOfElementWithText(
			    By.xpath(OR.getProperty(object)), ""));
	    // return element;

	    /*
	     * WebDriverWait innerwait = new WebDriverWait(driver, 60);
	     * innerwait.until(ExpectedConditions.presenceOfElementLocated(By
	     * .xpath(OR.getProperty(object))));
	     *//*
	        * List<WebElement> element1 = wait.until(ExpectedConditions
	        * .presenceOfAllElementsLocatedBy(By.xpath(object)));
	        */

	} catch (Exception e) {
	    Log.info("Not able to wait for Element visible --- "
		    + e.getMessage());
	}
    }

    @Test
    public static void UntilPrwait(String object, String data) {
	try {

	    Log.info("Untill wait for Element visible --- " + object);

	    Thread.sleep(5000);
	    // driver.manage().timeouts().implicitlyWait(2, TimeUnit.MINUTES);
	    // WebDriverWait wait = new WebDriverWait(driver, 50);

	    /*
	     * WebDriverWait innerwait = new WebDriverWait(driver, 60);
	     * innerwait.until(ExpectedConditions.presenceOfElementLocated(By
	     * .xpath(OR.getProperty(object))));
	     */

	} catch (Exception e) {
	    Log.info("Not able to wait for Element visible --- "
		    + e.getMessage());
	}
    }

    @Test
    public void FileuploadAutoit(String object, String data) {
	try {
	    Log.info("Upload file through AutoIt --- " + object);
	    driver.findElement(By.xpath(OR.getProperty(object))).click();
	    Runtime.getRuntime().exec(data.trim());
	} catch (Exception e) {
	    Log.info("Not able to Upload file through AutoIt --- "
		    + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;

	}
    }

    @SuppressWarnings("null")
    @Test
    public void ProxyLogin(String object, String data) {
	try {
	    Robot robot = new Robot();
	    WebElement alert = null;
	    alert.sendKeys("username");

	    robot.keyPress(KeyEvent.VK_TAB);// go to password feild

	    robot.keyPress(KeyEvent.VK_P);
	    robot.keyPress(KeyEvent.VK_A);
	    robot.keyPress(KeyEvent.VK_S);
	    robot.keyPress(KeyEvent.VK_S);

	    robot.keyPress(KeyEvent.VK_ENTER);

	} catch (AWTException e) {
	    e.printStackTrace();
	}
    }

    @Test
    public void VerifyAssertEqual(String object, String data) {
	try {
	    Log.info("Verify Assert Equal Text --- " + object);
	    String GetTxt = driver
		    .findElement(By.xpath(OR.getProperty(object))).getText();
	    if (data.contains(GetTxt)) {
		String mainWindow = getMainWindowHandle();
		closeAllOtherWindows(mainWindow);
	    }
	} catch (Exception e) {
	    Log.info("Not able to Verify Assert Equal Text --- "
		    + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;

	}
    }

    @Test
    public static void clear(String object, String data) {
	try {
	    Log.info("Entering the text in " + object);
	    driver.findElement(By.xpath(OR.getProperty(object))).clear();
	} catch (Exception e) {
	    Log.error("Not able to Entering the text --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;

	}
    }

    @Test
    public static void waitFor1min(String object, String data) throws Exception {
	try {
	    Log.info("Wait for 60 seconds");
	    driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
	} catch (Exception e) {
	    Log.error("Not able to Wait --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;

	}
    }

    @Test
    public static void SignatureAutoit(String object, String data) {
	try {
	    Log.info("Make signature through AutoIt --- ");
	    // driver.findElement(By.xpath(OR.getProperty(object))).click();
	    Runtime.getRuntime().exec(data.trim());
	} catch (Exception e) {

	    Log.error("Not able to Make signature --- " + e.getMessage());
	    TC001_Reports_Contract_Management.bResult = false;
	    TC002_Reports_Cost_Management.bResult = false;
	    TC003_Reports_Design_Management.bResult = false;
	    TC004_Reports_Logistic.bResult = false;
	    TC005_Reports_Project_Management.bResult = false;
	    TC006_Reports_Schedule_Management.bResult = false;
	}
    }

    private static void msgbox(String s) {
	JOptionPane.showMessageDialog(null, s);
    }

    @Test
    public static void StringCompare(String object, String data) {

	try {
	    Log.info("String Compare with current Text --- " + object);
	    WebElement Txt = driver
		    .findElement(By.xpath(OR.getProperty(object)));

	    String CheckText = Txt.getText();

	    for (int i = 0; i <= CheckText.indexOf('s', 0); i++) {
		if (CheckText.equals("Site id is not unique")) {
		    Log.info("Site id is not unique --- " + CheckText);
		    msgbox(CheckText + "\t : Please Enter new Site id");
		    @SuppressWarnings("resource")
		    Scanner newdata = new Scanner(System.in);
		    System.out.print("Please Enter new Site id");
		    String sUpdata = newdata.nextLine();
		    utility.Excelwrite.UpdateExcel(sUpdata);

		} else {
		    Log.info("Text not Matched with given value --- "
			    + CheckText);
		    System.out.println("Text not Matched with given value... ");

		}
	    }
	} catch (Exception e) {
	    Log.info("Not able to Validate current Text --- " + e.getMessage());
	}
    }

    @SuppressWarnings("null")
    @Test
    public void proxylogin(String object, String data) {

	try {
	    Robot robot = new Robot();
	    WebElement alert = null;
	    alert.sendKeys("karthik");

	    robot.keyPress(KeyEvent.VK_TAB);// go to password feild
	    alert.sendKeys("chembian");

	    robot.keyPress(KeyEvent.VK_P);
	    robot.keyPress(KeyEvent.VK_A);
	    robot.keyPress(KeyEvent.VK_S);
	    robot.keyPress(KeyEvent.VK_S);

	    robot.keyPress(KeyEvent.VK_ENTER);

	} catch (AWTException e) {
	    e.printStackTrace();
	}
    }

    @Test
    public static void ReportClick(String object, String data) {

	try {
	    Log.info("Click on Report link --- " + object);

	    int iTotalTestCases = ExcelUtils
		    .getRowCount(Constants.Sheet_TestCases);
	    for (int iTestcase = 1; iTestcase < iTotalTestCases; iTestcase++) {

		sReportRunMode = ExcelUtils.getCellData(iTestcase,
			Constants.Col_ReportRunmode, Constants.Sheet_Reports);

		WebElement Reportobj = driver.findElement(By.xpath(OR
			.getProperty(object)));
		if (sReportRunMode.equals("Yes")) {
		    WebDriverWait innerwait = new WebDriverWait(driver, 30);
		    innerwait.until(ExpectedConditions.elementToBeClickable(By
			    .xpath(OR.getProperty(object))));
		    Reportobj.click();
		    break;
		} else if (sReportRunMode.equals("No")) {
		    Log.info("Report Runmode in No status --- ");

		    ATUReports.add("Report Runmode status is No", LogAs.FAILED,
			    new CaptureScreen(ScreenshotOf.DESKTOP));
		    break;
		}
	    }

	} catch (Exception e) {

	    Log.info("Not able to Click on Report link --- " + e.getMessage());
	}

    }

    @Test
    public void waitForPageLoaded() {

	Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
		.withTimeout(30, TimeUnit.SECONDS)
		.pollingEvery(5, TimeUnit.SECONDS)
		.ignoring(NoSuchElementException.class);

	ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
	    public Boolean apply(WebDriver driver) {
		return ((JavascriptExecutor) driver).executeScript(
			"return document.readyState").equals("complete");
	    }
	};
	wait.until(pageLoadCondition);
    }

    @Test
    public void Switchframe(String object, String data) {
    	try {
			Log.info("Switch to frame --- " + data);
			driver.switchTo().frame(data);
		} catch (Exception e) {
			Log.error("Not able Switch to frame --- " + e.getMessage());
		}
    }

    @Test
    public static void ReportVal(String object, String data) {
	try {

	    Log.info("Report Validation for report --- " + object);
	    // int timeout = 60;
	    WebDriverWait innerwait = new WebDriverWait(driver, 120);
	    WebElement Rprtld = innerwait
		    .until(ExpectedConditions.visibilityOfElementLocated(By
			    .xpath("//*[@id='ReportViewer1_fixedTable']/tbody/tr[4]")));

	    WebElement RprtPrv = driver.findElement(By
		    .xpath("//*[@id='ReportViewer1_fixedTable']/tbody/tr[4]"));

	    /*
	     * WebElement RprtPrvLd = driver.findElement(By
	     * .id("ReportViewer1_AsyncWait_Wait"));
	     */

	    if (RprtPrv.isDisplayed()) {

		// System.out.println(RprtPrv.getSize());

		Validation(object, data);

		// ClsAllExcptMain(object, data);
	    } else {

		// System.out.println(RprtPrv.getSize());

		ATUReports.add("Report Preview Timeout", LogAs.FAILED,
			new CaptureScreen(ScreenshotOf.DESKTOP));
		// ClsAllExcptMain(object, data);
	    }

	} catch (Exception e) {
	    Log.error("Not able to do Report Validation for report --- "
		    + e.getMessage());
	}
    }

    @Test
    public static void ReportContVal(String object, String data) {
	try {

	    Log.info("After Report preview Validation for report --- " + object);

	    WebElement Rprcnt = driver.findElement(By
		    .xpath("//*[@id='ReportViewer1_fixedTable']/tbody/tr[4]"));

	    WebElement Rprldimg = driver.findElement(By
		    .xpath("//*[@id='ReportViewer1_AsyncWait_Wait']"));

	    /*
	     * WebElement NonRprcnt = driver .findElement(By
	     * .xpath("// *[@id='ReportViewer1_ctl09_NonReportContent']/div/ul/li"
	     * ));
	     */
	    // WebElement Test1 = driver.findElement(By.xpath(object));

	    String Rprterr = Rprcnt.getText();

	    if (Rprcnt.isDisplayed() && Rprterr.isEmpty()) {

		// Validation(object, data);

		if (Rprldimg.isDisplayed() || Rprterr.contains("Error")
			|| Rprterr.isEmpty()) {

		    ATUReports.add("Report not genarated successfully",
			    Rprterr, LogAs.FAILED, new CaptureScreen(
				    ScreenshotOf.DESKTOP));
		}
		// ClsAllExcptMain(object, data);
	    } else if (Rprcnt.isDisplayed()) {

		if (!Rprterr.isEmpty()) {
		    ATUReports.add("Report genarated successfully ",
			    LogAs.PASSED, new CaptureScreen(
				    ScreenshotOf.DESKTOP));
		}
		// ClsAllExcptMain(object, data);
	    }

	} catch (Exception e) {
	    Log.error("Not able to do Report Validation for report --- "
		    + e.getMessage());
	}
    }

    @Test
    public static void ReportValErr(String object, String data) {
	try {

	    Log.info("After Report preview Validation for report --- " + object);

	    WebElement Rprcnt = driver.findElement(By
		    .xpath("//*[@id='ReportViewer1_fixedTable']/tbody/tr[4]"));

	    /*
	     * WebElement NonRprcnt = driver .findElement(By
	     * .xpath("// *[@id='ReportViewer1_ctl09_NonReportContent']/div/ul/li"
	     * ));
	     */
	    // WebElement Test1 = driver.findElement(By.xpath(object));

	    String Rprterr = Rprcnt.getText();

	    if (Rprcnt.isDisplayed()) {

		// Validation(object, data);

		if (Rprterr.contains("Error") || Rprterr.isEmpty()) {

		    ATUReports.add("Report not genarated successfully",
			    Rprterr, LogAs.FAILED, new CaptureScreen(
				    ScreenshotOf.DESKTOP));
		}
		// ClsAllExcptMain(object, data);
	    } else {

		if (!Rprterr.isEmpty()) {
		    ATUReports.add("Report genarated successfully ",
			    LogAs.PASSED, new CaptureScreen(
				    ScreenshotOf.DESKTOP));
		}
		// ClsAllExcptMain(object, data);
	    }

	} catch (Exception e) {
	    Log.error("Not able to do Report Validation for report --- "
		    + e.getMessage());
	}
    }

    @Test
	public void KeysctrlF5(String object, String data) {
		try {
			Log.info("press Ctrl + F5 keys --- " + data);
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_F5);
			robot.keyRelease(KeyEvent.VK_F5);
			robot.keyRelease(KeyEvent.VK_CONTROL);

		} catch (Exception e) {
			Log.error("Not able to press Ctrl + F5 keys --- " + e.getMessage());
		}

	}
    
    @Test
    public void ReportClick_New(String object, String data) {
	try {

	    ArrayList<String> Dataset = new ArrayList<String>();
	    Dataset.add(data);
	    List<WebElement> linkElements = driver.findElements(By
		    .xpath(".//*[@id='Report']/tbody/tr"));
	    String[] linkTexts = new String[linkElements.size()];
	    int i = 0;
	    for (WebElement e : linkElements) {
		linkTexts[i] = e.getText();
		i++;
		if (Dataset.contains(e.getText())) {
		    driver.findElement(By.linkText((e.getText()))).click();
		    Thread.sleep(3000);
		}
	    }

	} catch (Exception e) {

	}
    }
}
