package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excelwrite {

    public static void UpdateExcel(String sUpdata) {
	String FileName = config.Constants.Path_TestData;

	try {
	    FileInputStream fileInputStream3 = new FileInputStream(FileName);
	    File outputsheetfile1 = new File(FileName);
	    if (outputsheetfile1.exists()) {
		System.out.println("File existed");
		try {
		    @SuppressWarnings("resource")
		    XSSFWorkbook ObjWorkBook = new XSSFWorkbook(
			    fileInputStream3);
		    XSSFSheet DriverTableSheet = ObjWorkBook.getSheetAt(2);
		    for (int i = 1; i < 2; i++) {
			XSSFRow row1 = DriverTableSheet.getRow(i);
			XSSFCell Cell1 = row1.getCell(4);

			System.out.println("Cell1" + Cell1);
			// System.out.println("Cell2"+ Cell2);
			String str = sUpdata;
			Cell1.setCellValue(str);

			FileOutputStream out1 = new FileOutputStream(FileName,
				false);
			ObjWorkBook.write(out1);
			fileInputStream3.close();
		    }

		} catch (IOException e) {
		    e.printStackTrace();
		}

	    }
	} catch (FileNotFoundException e) {
	    e.printStackTrace();
	}
    }
}