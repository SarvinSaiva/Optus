package executionEngine;

import java.io.IOException;

public class Run_Install_Java {

	public static void main(String[] args) {
		try {
	        //Process q =  Runtime.getRuntime().exec("cmd /c Silentmode.bat", null, new File("\\\\CIS20\\RunnableExe\\"));
	        String[] command = {"cmd.exe", "/C", "Start", "D:\\Automation\\RunnableExe\\install.bat"};
            @SuppressWarnings("unused")
			Process p =  Runtime.getRuntime().exec(command); 
            
            String[] commandexe = {"D:\\Automation\\RunnableExe\\InstallJava.exe"};
            @SuppressWarnings("unused")
			Process q =  Runtime.getRuntime().exec(commandexe);
	        
	    } catch (IOException ex) {
	    }
	}

}
