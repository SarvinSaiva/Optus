package MailUtility;

//File Name SendFileEmail.java

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

@SuppressWarnings("unused")
public class JavaMail {

    public void main(String string, String javamail) {

	// Recipient's email ID needs to be mentioned.
	// String to = "saivadurai.j8@gmail.com";
	String to = "balaji.m@chembiantech.com";
	// String to = "saivadurai.j@chembiantech.com";

	// Recipient's email ID needs to be mentioned.
	// String to1 = "sekar.n@chembiantech.com";

	// Recipient's email ID needs to be mentioned.
	String to2 = "karthik.s@chembiantech.com";
	// String to2 = "saivadurai.j@chembiantech.com";

	// Recipient's email ID needs to be mentioned.
	// String to3 = "akalya.t@chembiantech.com";

	// Recipient's email ID needs to be mentioned.
	// String to4 = "kaviya.s@chembiantech.com";

	// Recipient's email ID needs to be mentioned.
	// String mailCc1 = "MurugeshS@sulekha.net";
	String mailCc1 = "sekar.n@chembiantech.com";
	// String mailCc1 = "saivadurai.j@chembiantech.com";

	// Recipient's email ID needs to be mentioned.
	// String mailCc1 = "MurugeshS@sulekha.net";
	// String mailCc2 = "senthilkumar.s@chembiantech.com";

	// Recipient's email ID needs to be mentioned.
	// String mailCc1 = "MurugeshS@sulekha.net";
	// String mailCc3 = "sathya.d@chembiantech.com";

	// Recipient's email ID needs to be mentioned.
	// String mailCc1 = "MurugeshS@sulekha.net";
	String mailCc4 = "saivadurai.j@chembiantech.com";

	// Sender's email ID needs to be mentioned
	String from = "saivadurai.j@chembiantech.com";

	// Assuming you are sending email from localhost
	// String host = "smtp.gmail.com";
	String host = "192.168.1.100";

	// Get system properties
	Properties props = System.getProperties();

	// Setup mail server
	props.put("mail.smtp.host", "192.168.1.100");
	props.put("mail.smtp.ssl.port", "100");
	props.put("mail.smtp.ssl.class", "javax.net.ssl.SSLSocketFactory");
	props.put("mail.smtp.auth", "true");
	props.put("mail.smtp.port", "100");

	// Get the default Session object.
	Session session = Session.getInstance(props,
		new javax.mail.Authenticator() {
		    protected PasswordAuthentication getPasswordAuthentication() {
			return new PasswordAuthentication(
				"webtest@chintainfo.com", "web_2010_test");
		    }
		});

	try {
	    // Create a default MimeMessage object.
	    MimeMessage message = new MimeMessage(session);

	    // Set From: header field of the header.
	    message.setFrom(new InternetAddress(from));

	    // Set To: header field of the header.
	    message.addRecipient(Message.RecipientType.TO, new InternetAddress(
		    to));

	    // Set To1: header field of the header.
	    // message.addRecipient(Message.RecipientType.TO, new
	    // InternetAddress(
	    // to1));

	    // Set To2: header field of the header.
	    message.addRecipient(Message.RecipientType.TO, new InternetAddress(
		    to2));

	    // Set To3: header field of the header.
	    // message.addRecipient(Message.RecipientType.TO, new
	    // InternetAddress(
	    // to3));

	    // Set To4: header field of the header.
	    // message.addRecipient(Message.RecipientType.TO, new
	    // InternetAddress(
	    // to4));

	    // Set Cc: header field of the header.
	    // message.addRecipient(Message.RecipientType.CC, new
	    // InternetAddress(mailCc));

	    // Set Cc1: header field of the header.
	    message.addRecipient(Message.RecipientType.CC, new InternetAddress(
		    mailCc1));

	    // Set Cc2: header field of the header.
	    // message.addRecipient(Message.RecipientType.CC, new
	    // InternetAddress(
	    // mailCc2));

	    // Set Cc3: header field of the header.
	    // message.addRecipient(Message.RecipientType.CC, new
	    // InternetAddress(
	    // mailCc3));

	    // Set Cc4: header field of the header.
	    message.addRecipient(Message.RecipientType.CC, new InternetAddress(
		    mailCc4));

	    DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	    // get current date time with Date()
	    Date date = new Date();
	    // System.out.println(dateFormat.format(date));

	    // get current date time with Calendar()
	    Calendar cal = Calendar.getInstance();
	    // System.out.println(dateFormat.format(cal.getTime()));

	    // Set Subject: header field
	    message.setSubject("ZOptus Automation Results - " + cal.getTime());

	    // Create the message part
	    BodyPart messageBodyPart = new MimeBodyPart();

	    // Fill the message
	    messageBodyPart
		    .setText(" Hi Team,\n Please check the attached file for ZOptus Automated Test Results. \n Please Unzip the folder and then check emailable-report.html or Intex.html and let us know ( If Any issues) \n\n\n\n Thanks and Regards, \n Testing Team \n Chembian Technology");

	    // Create a multipar message
	    Multipart multipart = new MimeMultipart();

	    // Set text message part
	    multipart.addBodyPart(messageBodyPart);

	    // Part two is attachment
	    messageBodyPart = new MimeBodyPart();
	    String filename = "D:\\XSLT_Reports\\ZOptus_Output.zip";
	    // String filename =
	    // "\\\\CIS20\\XSLT_Reports\\target\\XSLT_Reports\\output\\index.html";
	    DataSource source = new FileDataSource(filename);
	    messageBodyPart.setDataHandler(new DataHandler(source));
	    messageBodyPart.setFileName(filename);
	    multipart.addBodyPart(messageBodyPart);

	    // Send the complete message parts
	    message.setContent(multipart);

	    // Send message
	    Transport.send(message);
	    System.out.println("Sent Mail to stack holders successfully....");
	} catch (MessagingException mex) {
	    mex.printStackTrace();
	}
    }
}
