package PageObject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LogIn_Page {
    static WebElement element = null;

    public static WebElement txtbx_UserName(WebDriver driver) {

	element = driver.findElement(By.id("txtUserName"));
	return element;
    }

    public static WebElement txtbx_Password(WebDriver driver) {

	element = driver.findElement(By.id("txtPassword"));
	return element;
    }

    public static WebElement btn_LogIn(WebDriver driver) {

	element = driver.findElement(By.id("btnLogin"));
	return element;

    }

    public static WebElement waitForLoad(WebDriver driver)
	    throws InterruptedException {
	driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
	return element;
    }
}
