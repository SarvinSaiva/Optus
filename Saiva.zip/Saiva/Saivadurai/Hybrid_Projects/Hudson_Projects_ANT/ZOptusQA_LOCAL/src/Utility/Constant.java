package Utility;

public class Constant {

    public static final String URL = "http://ibm-1/ZOptusQA";

    public static final String Username = "gulsar";

    public static final String Password = "password";

    public static final String Path_TestData = "D:\\Projects\\ZOptusQA_LOCAL\\TestData\\";

    public static final String File_TestData = "TestData.xlsx";

}
