package Zoptusmodule;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Utility.Constant;
import Utility.ExcelUtils;
import appmodule.Report_Action;
import appmodule.SignIn_Action;

public class TC008_Reports_Page {

    @SuppressWarnings("unused")
    private static WebElement element = null;

    WebDriver driver;

    @Test(priority = 1)
    public void Report_SignIn() throws Exception {

	ExcelUtils.setExcelFile(
		Constant.Path_TestData + Constant.File_TestData, "Sheet1");

	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.get(Constant.URL);
	SignIn_Action.Execute(driver);
    }

    @Test(priority = 2)
    public void PMO_PAGE() throws Exception {
	Report_Action RPA = new Report_Action();
	RPA.PMO_reports(driver);

    }

    @Test(priority = 3)
    public void Finance_PAGE() throws Exception {
	Report_Action RPA = new Report_Action();
	RPA.Finance_reports(driver);
    }

    @Test(priority = 4)
    public void Logistics_PAGE() throws Exception {
	Report_Action RPA = new Report_Action();
	RPA.Logistics_reports(driver);
    }

    @Test(priority = 5)
    public void Delivery_PAGE() throws Exception {
	Report_Action RPA = new Report_Action();
	RPA.Delivery_reports(driver);
    }

    @Test(priority = 6)
    public void ViewMap_PAGE() throws Exception {
	Report_Action RPA = new Report_Action();
	RPA.View_Map(driver);
    }

    @BeforeTest
    public void bft() {

	// ChromeOptions options = new ChromeOptions();
	System.setProperty("webdriver.chrome.logfile",
		"D:/ChromeDriver/chromedriver.log");
	System.setProperty("webdriver.chrome.driver",
		"D:/ChromeDriver/chromedriver.exe");
	ChromeOptions options = new ChromeOptions();
	options.addArguments(Arrays.asList("--disable-application-cache",
		"--disable-password-autofill-public-suffix-domain-matching",
		"--no-sandbox", "--start-maximized",
		"allow-running-insecure-content", "ignore-certificate-errors"));

	options.addArguments("chrome.switches", "--disable-extensions");
	/*
	 * System.setProperty("webdriver.chrome.driver",
	 * "D:/ChromeDriver/chromedriver.exe");
	 */
	driver = new ChromeDriver(options);
	driver.manage().window().maximize();
    }

    @AfterTest
    public void Aft() {
	driver.quit();
    }

}
