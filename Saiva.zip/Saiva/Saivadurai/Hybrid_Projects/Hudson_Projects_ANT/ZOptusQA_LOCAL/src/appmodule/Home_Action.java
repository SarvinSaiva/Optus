package appmodule;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;
import org.testng.annotations.Test;

import PageObject.Commercial_Page;
import PageObject.Home_Page;

public class Home_Action {

    @Test
    public void Home_click(WebDriver driver) throws Exception {

	Commercial_Page.waitForLoad(driver);
	WebElement element = driver.findElement(By
		.xpath(".//*[@id='Home']/img"));
	Actions action = new Actions(driver);
	action.moveToElement(element).build().perform();
	Commercial_Page.waitForLoad(driver);
	Home_Page.btn_searchdocs(driver).click();
	Commercial_Page.waitForLoad(driver);
	Verification_Action.Execute(driver);
	Reporter.log("Click on Home Page");
    }

}
