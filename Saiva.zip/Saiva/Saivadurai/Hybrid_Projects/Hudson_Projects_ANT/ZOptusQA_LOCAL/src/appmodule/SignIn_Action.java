package appmodule;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import PageObject.LogIn_Page;
import Utility.ExcelUtils;

public class SignIn_Action {
    public static void Execute(WebDriver driver) throws Exception {

	String sUserName = ExcelUtils.getCellData(1, 1);
	String sPassword = ExcelUtils.getCellData(1, 2);
	LogIn_Page.txtbx_UserName(driver).sendKeys(sUserName);
	Reporter.log("Entered Username : " + sUserName);
	LogIn_Page.waitForLoad(driver);
	LogIn_Page.txtbx_Password(driver).sendKeys(sPassword);
	Reporter.log("Entered Username : " + sPassword);
	LogIn_Page.waitForLoad(driver);
	LogIn_Page.btn_LogIn(driver).click();
	Reporter.log("Click on Login button");
	LogIn_Page.waitForLoad(driver);
	LogIn_Page.waitForLoad(driver);
	Verification_Action.Execute(driver);
    }

}
