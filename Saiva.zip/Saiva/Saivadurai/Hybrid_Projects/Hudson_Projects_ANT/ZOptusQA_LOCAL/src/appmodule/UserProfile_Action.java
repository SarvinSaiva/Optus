package appmodule;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

import PageObject.UserProfile_Page;

public class UserProfile_Action {

    @Test
    public void UserProfile_EditProfile(WebDriver driver) throws Exception {
	UserProfile_Page.tab_UserImage(driver).click();
	UserProfile_Page.waitForLoad(driver);
	UserProfile_Page.tab_EditProfile(driver).click();
	Reporter.log("Click on UserProfile - EditProfile Menu");
	UserProfile_Page.waitForLoad(driver);
	String winHandleBefore = driver.getWindowHandle();
	for (String winHandle : driver.getWindowHandles()) {
	    driver.switchTo().window(winHandle);
	    Verification_Action.Execute(driver);
	}
	driver.close();
	driver.switchTo().window(winHandleBefore);
    }

    @Test
    public void UserProfile_TimeSheet(WebDriver driver) throws Exception {

	UserProfile_Page.tab_UserImage(driver).click();
	UserProfile_Page.waitForLoad(driver);
	UserProfile_Page.tab_timesheet(driver).click();
	UserProfile_Page.waitForLoad(driver);
	Reporter.log("Click on UserProfile - Timesheet Menu");
	Verification_Action.Execute(driver);
	UserProfile_Page.waitForLoad(driver);
	UserProfile_Page.tab_timesheetnewentries(driver).click();
	UserProfile_Page.waitForLoad(driver);
	UserProfile_Page.tab_timesheetpastentries(driver).click();
	UserProfile_Page.waitForLoad(driver);
    }

    @Test
    public void userProfile_SwitchLogged(WebDriver driver) throws Exception {
	UserProfile_Page.tab_UserImage(driver).click();
	UserProfile_Page.waitForLoad(driver);
	UserProfile_Page.tab_switchlogged(driver).click();
	Reporter.log("Click on UserProfile - SwitchLogged Menu");
	UserProfile_Page.waitForLoad(driver);
	Verification_Action.Execute(driver);
	UserProfile_Page.waitForLoad(driver);
	UserProfile_Page.tab_switchloggedclose(driver).click();
	UserProfile_Page.waitForLoad(driver);
    }

    @Test
    public void UserProfile_Logout(WebDriver driver)
	    throws InterruptedException {
	UserProfile_Page.tab_UserImage(driver).click();
	UserProfile_Page.waitForLoad(driver);
	UserProfile_Page.tab_logout(driver).click();
	Reporter.log("Click on UserProfile - Logout Menu");
    }
}
