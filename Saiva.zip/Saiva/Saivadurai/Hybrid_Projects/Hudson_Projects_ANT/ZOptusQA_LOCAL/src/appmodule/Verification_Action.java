package appmodule;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class Verification_Action {

    static WebElement element = null;

    @Test
    public static void Execute(WebDriver driver) throws Exception {

	String actualTitle = driver.getTitle();
	System.out.println(actualTitle);
	if (driver.getTitle().endsWith("ShowErrorPage")
		|| actualTitle.contains("The resource cannot be found")
		|| actualTitle.contains("Runtime Error")
		|| actualTitle.contains("Error")) {
	    // System.out.println(actualTitle);
	    System.out.println("Error Page Found");

	    // driver.getCurrentUrl().equals("Test");
	    // Reporter.log(actualTitle);
	    Assert.fail(actualTitle + " : Error Page Found" + ",CurrentUrl : "
		    + driver.getCurrentUrl());
	    Reporter.log(actualTitle + " : Error Page Found" + ",CurrentUrl : "
		    + driver.getCurrentUrl());

	} else {
	    // System.out.println(actualTitle);
	    System.out.println("Page Found");
	    // Reporter.log(actualTitle);
	    Reporter.log(actualTitle + " : Page Found", true);
	}
    }
}
