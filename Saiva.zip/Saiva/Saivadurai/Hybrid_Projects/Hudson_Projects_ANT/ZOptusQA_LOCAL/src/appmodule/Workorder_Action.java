package appmodule;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;
import org.testng.annotations.Test;

import PageObject.WorkOrder_Page;

public class Workorder_Action {

    @Test
    public void WorkOrder_Details(WebDriver driver) throws Exception {

	WorkOrder_Page.txtbx_search(driver).sendKeys("m99");
	WorkOrder_Page.btn_Searchworkorder(driver).click();
	WebElement element = driver.findElement(By
		.xpath("//*[@id='WorkOrder']/img"));
	Actions action = new Actions(driver);
	action.moveToElement(element).build().perform();
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.btn_details(driver).click();
	WorkOrder_Page.waitForLoad(driver);
	Verification_Action.Execute(driver);
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.txtbx_Change_Work(driver).sendKeys("M99");
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.DwnKey_Change_Work(driver);
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.EnterKey_Change_Work(driver);
	WorkOrder_Page.waitForLoad(driver);
	Verification_Action.Execute(driver);
	Reporter.log("Click on Search workorder");
	WorkOrder_Page.waitForLoad(driver);
	// WorkOrder_Page.btn_editwrkorder(driver).click();
	Verification_Action.Execute(driver);
	Reporter.log("Click on Edit workorder");
	WorkOrder_Page.tab_resource(driver).click();
	Verification_Action.Execute(driver);
	Reporter.log("Click on WorkOrder - Resource Tab");
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.tab_saed(driver).click();
	Verification_Action.Execute(driver);
	Reporter.log("Click on WorkOrder - SAED Tab");
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.tab_build(driver).click();
	Verification_Action.Execute(driver);
	Reporter.log("Click on WorkOrder - Build Tab");
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.tab_comments(driver).click();
	Verification_Action.Execute(driver);
	Reporter.log("Click on WorkOrder - Comments Tab");
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.tab_finance(driver).click();
	Verification_Action.Execute(driver);
	Reporter.log("Click on WorkOrder - Finance Tab");
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.tab_ptw(driver).click();
	Verification_Action.Execute(driver);
	Reporter.log("Click on WorkOrder - PTW Tab");
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.tab_tags(driver).click();
	Verification_Action.Execute(driver);
	Reporter.log("Click on WorkOrder - Tags Tab");
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.tab_technology(driver).click();
	Verification_Action.Execute(driver);
	Reporter.log("Click on WorkOrder - Technology Tab");
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.tab_logs(driver).click();
	Verification_Action.Execute(driver);
	Reporter.log("Click on WorkOrder - Logs Tab");
	WorkOrder_Page.waitForLoad(driver);

    }

    @Test
    public void WorkOrder_Documents(WebDriver driver) throws Exception {

	WebElement element = driver.findElement(By
		.xpath("//*[@id='WorkOrder']/img"));
	Actions action = new Actions(driver);
	action.moveToElement(element).build().perform();
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.btn_documents(driver).click();
	Reporter.log("Click on WorkOrder - Documents Menu");
	WorkOrder_Page.waitForLoad(driver);
	Verification_Action.Execute(driver);
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.txtbx_Change_Work(driver).sendKeys("M99");
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.DwnKey_Change_Work(driver);
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.EnterKey_Change_Work(driver);
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.div_work(driver).click();
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.div_arrowwork(driver).click();
	Reporter.log("Click on Work Table arrow");
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.div_sitepack(driver).click();
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.div_arrowsitepack(driver).click();
	Reporter.log("Click on SitePack Table arrow");
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.div_quality(driver).click();
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.div_arrowquality(driver).click();
	Reporter.log("Click on Quality Table arrow");
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.div_site(driver).click();
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.div_arrowsite(driver).click();
	Reporter.log("Click on Site Table arrow");
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.div_program(driver).click();
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.div_arrowprogram(driver).click();
	Reporter.log("Click on Program Table arrow");
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.div_project(driver).click();
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.div_arrowproject(driver).click();
	Reporter.log("Click on Project Table arrow");
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.tab_siteforms(driver).click();
	Reporter.log("Click on Siteforms Table arrow");
	WorkOrder_Page.waitForLoad(driver);
    }

    @Test
    public void WorkOrder_IssueRegister(WebDriver driver) throws Exception {
	WebElement element1 = driver.findElement(By
		.xpath("//*[@id='WorkOrder']/img"));
	Actions action1 = new Actions(driver);
	action1.moveToElement(element1).build().perform();
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.btn_IssueRegister(driver).click();
	Reporter.log("Click on WorkOrder - IssueRegister Menu");
	Thread.sleep(4000);
	Verification_Action.Execute(driver);
    }

    @Test
    public void WorkOrder_Faults(WebDriver driver) throws Exception {
	WebElement element1 = driver.findElement(By
		.xpath("//*[@id='WorkOrder']/img"));
	Actions action1 = new Actions(driver);
	action1.moveToElement(element1).build().perform();
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.btn_Faults(driver).click();
	Reporter.log("Click on WorkOrder - Faults Menu");
	Thread.sleep(4000);
	Verification_Action.Execute(driver);
    }

    @Test
    public void WorkOrder_Snag(WebDriver driver) throws Exception {
	WebElement element1 = driver.findElement(By
		.xpath("//*[@id='WorkOrder']/img"));
	Actions action1 = new Actions(driver);
	action1.moveToElement(element1).build().perform();
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.btn_snag(driver).click();
	Reporter.log("Click on WorkOrder - Snag Menu");
	Thread.sleep(4000);
	Verification_Action.Execute(driver);
    }

    @Test
    public void WorkOrder_MaterialOrder(WebDriver driver) throws Exception {
	WebElement element2 = driver.findElement(By
		.xpath("//*[@id='WorkOrder']/img"));
	Actions action2 = new Actions(driver);
	action2.moveToElement(element2).build().perform();
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.btn_materialordrng(driver).click();
	Reporter.log("Click on WorkOrder - Materialorder Menu");
	WorkOrder_Page.waitForLoad(driver);
	Verification_Action.Execute(driver);
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.tab_mtrlexternal(driver).click();
	Reporter.log("Click on Materialorder - External Tab");
	Verification_Action.Execute(driver);
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.tab_mtrlprevious(driver).click();
	Reporter.log("Click on Materialorder - Previous Tab");
	Verification_Action.Execute(driver);
	WorkOrder_Page.waitForLoad(driver);

    }

    @Test
    public void WorkOrder_Milestone(WebDriver driver) throws Exception {
	WebElement element3 = driver.findElement(By
		.xpath("//*[@id='WorkOrder']/img"));
	Actions action3 = new Actions(driver);
	action3.moveToElement(element3).build().perform();
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.btn_milestone(driver).click();
	Reporter.log("Click on WorkOrder - Milestone Menu");
	WorkOrder_Page.waitForLoad(driver);
	Verification_Action.Execute(driver);
    }

    @Test
    public void WorkOrder_BudgetTracker(WebDriver driver) throws Exception {
	WebElement element4 = driver.findElement(By
		.xpath("//*[@id='WorkOrder']/img"));
	Actions action4 = new Actions(driver);
	action4.moveToElement(element4).build().perform();
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.btn_budgettrcker(driver).click();
	Reporter.log("Click on WorkOrder - Budget Tracker Menu");
	WorkOrder_Page.waitForLoad(driver);
	Verification_Action.Execute(driver);
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.tab_phase1(driver).click();
	Reporter.log("Click on Budget Tracker - Phase1 Tab");
	Verification_Action.Execute(driver);
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.tab_phase2(driver).click();
	Reporter.log("Click on Budget Tracker - Phase2 Tab");
	Verification_Action.Execute(driver);
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.tab_phase3(driver).click();
	Reporter.log("Click on Budget Tracker - Phase3 Tab");
	Verification_Action.Execute(driver);
	WorkOrder_Page.waitForLoad(driver);
	WorkOrder_Page.tab_phase4(driver).click();
	Reporter.log("Click on Budget Tracker - Phase4 Tab");
	Verification_Action.Execute(driver);
	WorkOrder_Page.waitForLoad(driver);

    }

}
