package executionEngine;

import java.util.ArrayList;
import java.util.List;

import org.testng.TestListenerAdapter;
import org.testng.TestNG;

public class Run_Optus_PVT {

    public static void main(String[] args) {
	TestListenerAdapter tla = new TestListenerAdapter();
	List<String> file = new ArrayList<String>();
	file.add("D://Projects//Optus_Hybrid_PVT_RJ//VizWireless_Optus_PVT.xml");
	TestNG testng = new TestNG();
	testng.addListener(tla);
	testng.setTestSuites(file);
	testng.run();
    }

}
